import { useCallback } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function useAI() {
  const { toast } = useToast();

  const analyzeSuggestions = useCallback(async (fileId: number, content: string, language: string) => {
    try {
      const response = await apiRequest("POST", `/api/files/${fileId}/analyze`, {
        content,
        language,
      });
      return await response.json();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to analyze code",
        variant: "destructive",
      });
      throw error;
    }
  }, [toast]);

  const getCodeCompletions = useCallback(async (code: string, language: string, cursorPosition: number) => {
    try {
      const response = await apiRequest("POST", "/api/ai/complete", {
        code,
        language,
        cursorPosition,
      });
      return await response.json();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get code completions",
        variant: "destructive",
      });
      throw error;
    }
  }, [toast]);

  const fixCode = useCallback(async (code: string, language: string, errorMessage: string) => {
    try {
      const response = await apiRequest("POST", "/api/ai/fix", {
        code,
        language,
        errorMessage,
      });
      return await response.json();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fix code",
        variant: "destructive",
      });
      throw error;
    }
  }, [toast]);

  return {
    analyzeSuggestions,
    getCodeCompletions,
    fixCode,
  };
}
