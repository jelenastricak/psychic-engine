export class CodeExecutor {
  private worker: Worker | null = null;

  constructor() {
    this.initializeWorker();
  }

  private initializeWorker() {
    const workerCode = `
      self.onmessage = function(e) {
        const { code, language } = e.data;
        
        try {
          let result;
          
          if (language === 'javascript') {
            // Create a safe execution environment
            const output = [];
            const consoleLog = (...args) => {
              output.push(args.map(arg => 
                typeof arg === 'object' ? JSON.stringify(arg) : String(arg)
              ).join(' '));
            };
            
            // Override console in the execution context
            const safeCode = \`
              const console = { log: (\${consoleLog.toString()}) };
              \${code}
            \`;
            
            result = eval(safeCode);
            
            if (result !== undefined) {
              output.push(String(result));
            }
            
            self.postMessage({
              success: true,
              output: output.join('\\n'),
              error: null
            });
          } else {
            self.postMessage({
              success: false,
              output: '',
              error: 'Language not supported in web worker'
            });
          }
        } catch (error) {
          self.postMessage({
            success: false,
            output: '',
            error: error.message
          });
        }
      };
    `;

    const blob = new Blob([workerCode], { type: 'application/javascript' });
    this.worker = new Worker(URL.createObjectURL(blob));
  }

  async executeCode(code: string, language: string): Promise<{
    output: string;
    error: string | null;
  }> {
    if (!this.worker) {
      this.initializeWorker();
    }

    return new Promise((resolve) => {
      if (!this.worker) {
        resolve({
          output: '',
          error: 'Worker not available'
        });
        return;
      }

      const timeout = setTimeout(() => {
        resolve({
          output: '',
          error: 'Execution timeout'
        });
      }, 5000);

      this.worker.onmessage = (e) => {
        clearTimeout(timeout);
        const { success, output, error } = e.data;
        resolve({
          output: success ? output : '',
          error: success ? null : error
        });
      };

      this.worker.postMessage({ code, language });
    });
  }

  destroy() {
    if (this.worker) {
      this.worker.terminate();
      this.worker = null;
    }
  }
}

export const codeExecutor = new CodeExecutor();
