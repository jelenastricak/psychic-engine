import { useState, useEffect } from "react";
import { useParams } from "wouter";
import Header from "@/components/Header";
import FileExplorer from "@/components/FileExplorer";
import CodeEditor from "@/components/CodeEditor";
import OutputPanel from "@/components/OutputPanel";
import StatusBar from "@/components/StatusBar";
import { useProjects } from "@/hooks/useProjects";
import { useFiles } from "@/hooks/useFiles";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, FolderOpen } from "lucide-react";
import type { Project, File } from "@shared/schema";

export default function Editor() {
  const { projectId } = useParams<{ projectId: string }>();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [activeTab, setActiveTab] = useState<"preview" | "console" | "debug">("preview");
  const [openFiles, setOpenFiles] = useState<File[]>([]);
  
  const { projects, createProject, isLoading: projectsLoading } = useProjects();
  const { files, isLoading: filesLoading } = useFiles(projectId ? parseInt(projectId) : undefined);

  const currentProject = projects?.find(p => p.id === parseInt(projectId || "0"));

  useEffect(() => {
    if (files && files.length > 0 && !selectedFile) {
      const mainFile = files.find(f => f.name.startsWith("main.")) || files[0];
      setSelectedFile(mainFile);
      setOpenFiles([mainFile]);
    }
  }, [files, selectedFile]);

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    if (!openFiles.find(f => f.id === file.id)) {
      setOpenFiles([...openFiles, file]);
    }
  };

  const handleCloseFile = (file: File) => {
    const newOpenFiles = openFiles.filter(f => f.id !== file.id);
    setOpenFiles(newOpenFiles);
    if (selectedFile?.id === file.id) {
      setSelectedFile(newOpenFiles[0] || null);
    }
  };

  const handleCreateProject = async (name: string, language: string) => {
    await createProject({
      name,
      description: `A ${language} project`,
      language,
      isPublic: false,
    });
  };

  if (projectsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-dark-bg">
        <div className="text-dark-text">Loading projects...</div>
      </div>
    );
  }

  if (!currentProject && projectId) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-dark-bg">
        <Card className="w-full max-w-md mx-4 bg-dark-surface border-dark-border">
          <CardContent className="pt-6">
            <div className="text-center">
              <FolderOpen className="h-12 w-12 text-dark-text-secondary mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-dark-text mb-2">Project not found</h2>
              <p className="text-dark-text-secondary mb-4">
                The project you're looking for doesn't exist or has been deleted.
              </p>
              <Button 
                onClick={() => window.location.href = "/"}
                className="bg-vscode-blue hover:bg-blue-600"
              >
                Go back to projects
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!projects || projects.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-dark-bg">
        <Card className="w-full max-w-md mx-4 bg-dark-surface border-dark-border">
          <CardContent className="pt-6">
            <div className="text-center">
              <Plus className="h-12 w-12 text-dark-text-secondary mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-dark-text mb-2">No projects yet</h2>
              <p className="text-dark-text-secondary mb-4">
                Create your first project to start coding
              </p>
              <div className="space-y-2">
                <Button 
                  onClick={() => handleCreateProject("My JavaScript Project", "javascript")}
                  className="w-full bg-vscode-blue hover:bg-blue-600"
                >
                  Create JavaScript Project
                </Button>
                <Button 
                  onClick={() => handleCreateProject("My Python Project", "python")}
                  className="w-full bg-success-green hover:bg-green-600"
                >
                  Create Python Project
                </Button>
                <Button 
                  onClick={() => handleCreateProject("My Web Project", "html")}
                  className="w-full bg-warning-amber hover:bg-amber-600"
                >
                  Create HTML Project
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-dark-bg text-dark-text">
      <Header 
        currentProject={currentProject} 
        onRunCode={() => {}} 
        onCreateProject={handleCreateProject}
      />
      
      <div className="flex flex-1 overflow-hidden">
        <FileExplorer 
          projects={projects}
          currentProject={currentProject}
          files={files || []}
          selectedFile={selectedFile}
          onFileSelect={handleFileSelect}
          filesLoading={filesLoading}
        />
        
        <main className="flex-1 flex flex-col">
          {/* Editor Tabs */}
          <div className="bg-dark-surface border-b border-dark-border flex items-center overflow-x-auto">
            <div className="flex">
              {openFiles.map((file) => (
                <div 
                  key={file.id}
                  className={`border-r border-dark-border flex items-center px-4 py-2 text-sm cursor-pointer ${
                    selectedFile?.id === file.id ? 'bg-dark-bg text-dark-text' : 'text-dark-text-secondary hover:text-dark-text'
                  }`}
                  onClick={() => setSelectedFile(file)}
                >
                  <i className={`fas fa-file-code text-xs mr-2 ${getFileIcon(file.language)}`}></i>
                  <span>{file.name}</span>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCloseFile(file);
                    }}
                    className="ml-3 text-dark-text-secondary hover:text-dark-text"
                  >
                    <i className="fas fa-times text-xs"></i>
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="flex-1 flex">
            <CodeEditor 
              file={selectedFile}
              onCodeChange={() => {}}
            />
            <OutputPanel 
              activeTab={activeTab}
              onTabChange={setActiveTab}
              project={currentProject}
              selectedFile={selectedFile}
            />
          </div>
        </main>
      </div>
      
      <StatusBar 
        selectedFile={selectedFile}
        currentProject={currentProject}
      />
    </div>
  );
}

function getFileIcon(language: string): string {
  switch (language) {
    case "javascript":
      return "text-success-green";
    case "python":
      return "text-green-400";
    case "html":
      return "text-vscode-blue";
    case "css":
      return "text-purple-400";
    case "typescript":
      return "text-blue-400";
    default:
      return "text-dark-text-secondary";
  }
}
