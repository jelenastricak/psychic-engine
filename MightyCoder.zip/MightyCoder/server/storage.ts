import { 
  users, 
  projects, 
  files, 
  aiSuggestions, 
  codeExecutions,
  type User, 
  type InsertUser, 
  type Project, 
  type InsertProject,
  type File,
  type InsertFile,
  type AiSuggestion,
  type InsertAiSuggestion,
  type CodeExecution,
  type InsertCodeExecution
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Project operations
  getProject(id: number): Promise<Project | undefined>;
  getProjectsByUserId(userId: number): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project>;
  deleteProject(id: number): Promise<void>;
  
  // File operations
  getFile(id: number): Promise<File | undefined>;
  getFilesByProjectId(projectId: number): Promise<File[]>;
  createFile(file: InsertFile): Promise<File>;
  updateFile(id: number, file: Partial<InsertFile>): Promise<File>;
  deleteFile(id: number): Promise<void>;
  
  // AI suggestions
  getAiSuggestionsByFileId(fileId: number): Promise<AiSuggestion[]>;
  createAiSuggestion(suggestion: InsertAiSuggestion): Promise<AiSuggestion>;
  updateAiSuggestion(id: number, suggestion: Partial<InsertAiSuggestion>): Promise<AiSuggestion>;
  
  // Code execution
  createCodeExecution(execution: InsertCodeExecution): Promise<CodeExecution>;
  getCodeExecutionsByProjectId(projectId: number): Promise<CodeExecution[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async getProjectsByUserId(userId: number): Promise<Project[]> {
    return await db.select().from(projects).where(eq(projects.userId, userId)).orderBy(desc(projects.updatedAt));
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const [project] = await db.insert(projects).values(insertProject).returning();
    return project;
  }

  async updateProject(id: number, projectData: Partial<InsertProject>): Promise<Project> {
    const [project] = await db.update(projects)
      .set({ ...projectData, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return project;
  }

  async deleteProject(id: number): Promise<void> {
    await db.delete(projects).where(eq(projects.id, id));
  }

  async getFile(id: number): Promise<File | undefined> {
    const [file] = await db.select().from(files).where(eq(files.id, id));
    return file;
  }

  async getFilesByProjectId(projectId: number): Promise<File[]> {
    return await db.select().from(files).where(eq(files.projectId, projectId));
  }

  async createFile(insertFile: InsertFile): Promise<File> {
    const [file] = await db.insert(files).values(insertFile).returning();
    return file;
  }

  async updateFile(id: number, fileData: Partial<InsertFile>): Promise<File> {
    const [file] = await db.update(files)
      .set({ ...fileData, updatedAt: new Date() })
      .where(eq(files.id, id))
      .returning();
    return file;
  }

  async deleteFile(id: number): Promise<void> {
    await db.delete(files).where(eq(files.id, id));
  }

  async getAiSuggestionsByFileId(fileId: number): Promise<AiSuggestion[]> {
    return await db.select().from(aiSuggestions).where(eq(aiSuggestions.fileId, fileId));
  }

  async createAiSuggestion(insertSuggestion: InsertAiSuggestion): Promise<AiSuggestion> {
    const [suggestion] = await db.insert(aiSuggestions).values(insertSuggestion).returning();
    return suggestion;
  }

  async updateAiSuggestion(id: number, suggestionData: Partial<InsertAiSuggestion>): Promise<AiSuggestion> {
    const [suggestion] = await db.update(aiSuggestions)
      .set(suggestionData)
      .where(eq(aiSuggestions.id, id))
      .returning();
    return suggestion;
  }

  async createCodeExecution(insertExecution: InsertCodeExecution): Promise<CodeExecution> {
    const [execution] = await db.insert(codeExecutions).values(insertExecution).returning();
    return execution;
  }

  async getCodeExecutionsByProjectId(projectId: number): Promise<CodeExecution[]> {
    return await db.select().from(codeExecutions)
      .where(eq(codeExecutions.projectId, projectId))
      .orderBy(desc(codeExecutions.createdAt));
  }
}

export const storage = new DatabaseStorage();
