# CodeCraft IDE

## Overview

CodeCraft IDE is a full-stack web-based code editor built with React and Express. It provides a modern development environment with AI-powered code assistance, real-time collaboration features, and multi-language support. The application features a Monaco editor for code editing, project management, file system operations, and AI-powered code analysis and suggestions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Routing**: Wouter for client-side routing
- **State Management**: React Query (TanStack Query) for server state management
- **UI Library**: Radix UI components with Tailwind CSS for styling
- **Code Editor**: Monaco Editor with WebAssembly support

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Management**: PostgreSQL session store
- **Build Process**: ESBuild for production bundling

## Key Components

### Database Schema
The application uses a PostgreSQL database with the following main tables:
- **users**: User authentication and profile information
- **projects**: Project metadata including name, description, and language
- **files**: File system structure with support for directories and file content
- **aiSuggestions**: AI-generated code suggestions and improvements
- **codeExecutions**: History of code execution results and performance metrics

### Core Services
- **AI Service**: OpenAI GPT-4o integration for code analysis, completions, and error fixing
- **Code Execution Service**: Sandboxed code execution supporting JavaScript, Python, and HTML
- **Storage Service**: Database operations for all CRUD operations
- **File Management**: Hierarchical file system with directory support

### Frontend Features
- **Monaco Editor**: Full-featured code editor with syntax highlighting and IntelliSense
- **File Explorer**: Tree-view file navigation with context menus
- **AI Assistant**: Real-time code analysis and suggestions panel
- **Output Panel**: Multi-tab interface for preview, console output, and debugging
- **Project Management**: Create, edit, and manage coding projects
- **Responsive Design**: Mobile-friendly interface with collapsible panels

## Data Flow

### Project Creation Flow
1. User creates a new project via the header menu
2. Frontend sends project data to `/api/projects` endpoint
3. Backend creates project record and default files
4. Database stores project and file information
5. Frontend redirects to the new project editor

### Code Editing Flow
1. User selects a file from the file explorer
2. Monaco editor loads file content
3. Real-time auto-save triggers after 2 seconds of inactivity
4. AI service analyzes code in the background
5. Suggestions appear in the AI assistant panel

### Code Execution Flow
1. User clicks run button or uses keyboard shortcut
2. Frontend sends code to `/api/projects/{id}/execute`
3. Backend executes code in sandboxed environment
4. Results are returned and displayed in output panel
5. Execution history is stored in database

## External Dependencies

### Core Dependencies
- **@monaco-editor/react**: Code editor component
- **@neondatabase/serverless**: PostgreSQL database client
- **@tanstack/react-query**: Server state management
- **drizzle-orm**: Type-safe database ORM
- **express**: Web application framework
- **openai**: AI service integration
- **@radix-ui/react-***: UI component library
- **tailwindcss**: Utility-first CSS framework

### Development Dependencies
- **vite**: Build tool and development server
- **typescript**: Type checking and compilation
- **tsx**: TypeScript execution for development
- **esbuild**: Production bundling

## Deployment Strategy

### Development Environment
- **Command**: `npm run dev`
- **Server**: Vite development server with HMR
- **Database**: Connected to Neon Database via DATABASE_URL
- **AI Service**: OpenAI API integration

### Production Build
- **Frontend**: Vite builds React app to `dist/public`
- **Backend**: ESBuild bundles Node.js server to `dist/index.js`
- **Assets**: Static files served from built frontend
- **Database**: Production PostgreSQL via Neon Database

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string (required)
- `OPENAI_API_KEY`: OpenAI API key for AI features
- `NODE_ENV`: Environment setting (development/production)

### File Structure
- `client/`: React frontend application
- `server/`: Express backend application
- `shared/`: Shared TypeScript types and schemas
- `migrations/`: Database migration files
- `dist/`: Production build output

The application is designed to be deployed on platforms like Replit, Vercel, or similar services with support for full-stack Node.js applications and PostgreSQL databases.