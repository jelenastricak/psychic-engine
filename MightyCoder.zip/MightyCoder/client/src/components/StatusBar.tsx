import { Badge } from "@/components/ui/badge";
import { CheckCircle, GitBranch, FileText, Zap } from "lucide-react";
import type { Project, File } from "@shared/schema";

interface StatusBarProps {
  selectedFile: File | null;
  currentProject?: Project;
}

export default function StatusBar({ selectedFile, currentProject }: StatusBarProps) {
  const getLanguageDisplay = (language: string) => {
    switch (language) {
      case "javascript":
        return "JavaScript";
      case "python":
        return "Python";
      case "html":
        return "HTML";
      case "css":
        return "CSS";
      case "typescript":
        return "TypeScript";
      default:
        return "Text";
    }
  };

  const getLanguageIcon = (language: string) => {
    switch (language) {
      case "javascript":
        return "text-success-green";
      case "python":
        return "text-green-400";
      case "html":
        return "text-vscode-blue";
      case "css":
        return "text-purple-400";
      case "typescript":
        return "text-blue-400";
      default:
        return "text-dark-text-secondary";
    }
  };

  return (
    <div className="bg-dark-surface border-t border-dark-border flex items-center justify-between px-4 py-1 text-xs">
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-success-green rounded-full"></div>
          <span className="text-dark-text-secondary">Ready</span>
        </div>
        
        {selectedFile && (
          <div className="flex items-center space-x-2">
            <FileText className={`h-3 w-3 ${getLanguageIcon(selectedFile.language)}`} />
            <span>{getLanguageDisplay(selectedFile.language)}</span>
          </div>
        )}
        
        {currentProject && (
          <div className="flex items-center space-x-2">
            <GitBranch className="h-3 w-3 text-warning-amber" />
            <span>{currentProject.name}</span>
          </div>
        )}
      </div>
      
      <div className="flex items-center space-x-4">
        {selectedFile && (
          <>
            <span className="text-dark-text-secondary">
              {selectedFile.name}
            </span>
            <span className="text-dark-text-secondary">UTF-8</span>
            <span className="text-dark-text-secondary">LF</span>
          </>
        )}
        
        <div className="flex items-center space-x-1">
          <CheckCircle className="h-3 w-3 text-success-green" />
          <span className="text-dark-text-secondary">Auto-saved</span>
        </div>
      </div>
    </div>
  );
}
