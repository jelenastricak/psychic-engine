import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import AIAssistant from "@/components/AIAssistant";
import { 
  FilePlus, 
  FolderPlus, 
  RefreshCw, 
  Folder, 
  FolderOpen,
  FileText,
  Code,
  Loader2
} from "lucide-react";
import type { Project, File } from "@shared/schema";

interface FileExplorerProps {
  projects: Project[];
  currentProject?: Project;
  files: File[];
  selectedFile: File | null;
  onFileSelect: (file: File) => void;
  filesLoading: boolean;
}

export default function FileExplorer({ 
  projects, 
  currentProject, 
  files, 
  selectedFile, 
  onFileSelect,
  filesLoading 
}: FileExplorerProps) {
  const getFileIcon = (file: File) => {
    if (file.isDirectory) {
      return <Folder className="text-warning-amber h-4 w-4" />;
    }
    
    switch (file.language) {
      case "javascript":
        return <Code className="text-success-green h-4 w-4" />;
      case "python":
        return <Code className="text-green-400 h-4 w-4" />;
      case "html":
        return <Code className="text-vscode-blue h-4 w-4" />;
      case "css":
        return <Code className="text-purple-400 h-4 w-4" />;
      case "typescript":
        return <Code className="text-blue-400 h-4 w-4" />;
      default:
        return <FileText className="text-dark-text-secondary h-4 w-4" />;
    }
  };

  return (
    <aside className="w-64 bg-dark-surface border-r border-dark-border flex flex-col">
      {/* File Explorer Header */}
      <div className="flex items-center justify-between p-3 border-b border-dark-border">
        <span className="text-sm font-medium uppercase tracking-wide text-dark-text-secondary">
          Explorer
        </span>
        <div className="flex space-x-1">
          <Button 
            variant="ghost" 
            size="sm" 
            className="p-1 hover:bg-dark-bg"
            onClick={() => {}}
          >
            <FilePlus className="h-3 w-3 text-dark-text-secondary" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="p-1 hover:bg-dark-bg"
            onClick={() => {}}
          >
            <FolderPlus className="h-3 w-3 text-dark-text-secondary" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="p-1 hover:bg-dark-bg"
            onClick={() => {}}
          >
            <RefreshCw className="h-3 w-3 text-dark-text-secondary" />
          </Button>
        </div>
      </div>

      {/* Project Tree */}
      <ScrollArea className="flex-1 p-2">
        {currentProject ? (
          <div className="space-y-1">
            <div className="flex items-center space-x-2 p-1 mb-2">
              <FolderOpen className="text-warning-amber h-4 w-4" />
              <span className="font-medium text-dark-text">{currentProject.name}</span>
            </div>
            
            {filesLoading ? (
              <div className="flex items-center space-x-2 p-2 text-dark-text-secondary">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span className="text-sm">Loading files...</span>
              </div>
            ) : (
              <div className="ml-4 space-y-1">
                {files.map((file) => (
                  <div
                    key={file.id}
                    className={`flex items-center space-x-2 p-1 rounded cursor-pointer text-sm ${
                      selectedFile?.id === file.id
                        ? 'bg-vscode-blue bg-opacity-20 text-vscode-blue'
                        : 'hover:bg-dark-bg text-dark-text'
                    }`}
                    onClick={() => onFileSelect(file)}
                  >
                    {getFileIcon(file)}
                    <span>{file.name}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="p-4 text-center text-dark-text-secondary">
            <div className="space-y-2">
              <p className="text-sm">Select a project to view files</p>
              {projects.length > 0 && (
                <div className="space-y-1">
                  <p className="text-xs uppercase tracking-wide">Available Projects:</p>
                  {projects.map((project) => (
                    <Button
                      key={project.id}
                      variant="ghost"
                      className="w-full justify-start p-2 h-auto text-left"
                      onClick={() => window.location.href = `/project/${project.id}`}
                    >
                      <Folder className="h-4 w-4 mr-2 text-warning-amber" />
                      <div>
                        <div className="text-sm font-medium">{project.name}</div>
                        <div className="text-xs text-dark-text-secondary">{project.language}</div>
                      </div>
                    </Button>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </ScrollArea>

      {/* AI Assistant Panel */}
      <AIAssistant selectedFile={selectedFile} />
    </aside>
  );
}
