import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProjectSchema, insertFileSchema, insertCodeExecutionSchema } from "@shared/schema";
import { aiService } from "./services/aiService";
import { codeExecutionService } from "./services/codeExecutionService";

export async function registerRoutes(app: Express): Promise<Server> {
  // Projects
  app.get("/api/projects", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const projects = await storage.getProjectsByUserId(userId);
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const data = insertProjectSchema.parse(req.body);
      const project = await storage.createProject({ ...data, userId: 1 }); // TODO: Get from auth
      
      // Create default files for the project
      await storage.createFile({
        name: "main." + getFileExtension(data.language || "javascript"),
        path: "/main." + getFileExtension(data.language || "javascript"),
        content: getDefaultContent(data.language || "javascript"),
        language: data.language || "javascript",
        projectId: project.id,
        isDirectory: false,
        parentId: undefined,
      });

      res.json(project);
    } catch (error) {
      res.status(400).json({ message: "Invalid project data" });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.getProject(parseInt(req.params.id));
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.put("/api/projects/:id", async (req, res) => {
    try {
      const data = insertProjectSchema.partial().parse(req.body);
      const project = await storage.updateProject(parseInt(req.params.id), data);
      res.json(project);
    } catch (error) {
      res.status(400).json({ message: "Invalid project data" });
    }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      await storage.deleteProject(parseInt(req.params.id));
      res.json({ message: "Project deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete project" });
    }
  });

  // Files
  app.get("/api/projects/:projectId/files", async (req, res) => {
    try {
      const files = await storage.getFilesByProjectId(parseInt(req.params.projectId));
      res.json(files);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch files" });
    }
  });

  app.post("/api/projects/:projectId/files", async (req, res) => {
    try {
      const data = insertFileSchema.parse({
        ...req.body,
        projectId: parseInt(req.params.projectId),
      });
      const file = await storage.createFile(data);
      res.json(file);
    } catch (error) {
      res.status(400).json({ message: "Invalid file data" });
    }
  });

  app.get("/api/files/:id", async (req, res) => {
    try {
      const file = await storage.getFile(parseInt(req.params.id));
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      res.json(file);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch file" });
    }
  });

  app.put("/api/files/:id", async (req, res) => {
    try {
      const data = insertFileSchema.partial().parse(req.body);
      const file = await storage.updateFile(parseInt(req.params.id), data);
      res.json(file);
    } catch (error) {
      res.status(400).json({ message: "Invalid file data" });
    }
  });

  app.delete("/api/files/:id", async (req, res) => {
    try {
      await storage.deleteFile(parseInt(req.params.id));
      res.json({ message: "File deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete file" });
    }
  });

  // AI Suggestions
  app.get("/api/files/:fileId/suggestions", async (req, res) => {
    try {
      const suggestions = await storage.getAiSuggestionsByFileId(parseInt(req.params.fileId));
      res.json(suggestions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch AI suggestions" });
    }
  });

  app.post("/api/files/:fileId/analyze", async (req, res) => {
    try {
      const { content, language } = req.body;
      const fileId = parseInt(req.params.fileId);
      
      const suggestions = await aiService.analyzeCode(content, language);
      
      // Store suggestions in database
      for (const suggestion of suggestions) {
        await storage.createAiSuggestion({
          fileId,
          suggestion: suggestion.message,
          type: suggestion.type,
          lineNumber: suggestion.lineNumber || undefined,
        });
      }
      
      res.json(suggestions);
    } catch (error) {
      res.status(500).json({ message: "Failed to analyze code" });
    }
  });

  // Code Execution
  app.post("/api/projects/:projectId/execute", async (req, res) => {
    try {
      const data = insertCodeExecutionSchema.parse({
        ...req.body,
        projectId: parseInt(req.params.projectId),
      });
      
      const result = await codeExecutionService.executeCode(data.code, data.language);
      
      const execution = await storage.createCodeExecution({
        ...data,
        output: result.output,
        error: result.error || undefined,
        executionTime: result.executionTime,
      });
      
      res.json(execution);
    } catch (error) {
      res.status(500).json({ message: "Failed to execute code" });
    }
  });

  app.get("/api/projects/:projectId/executions", async (req, res) => {
    try {
      const executions = await storage.getCodeExecutionsByProjectId(parseInt(req.params.projectId));
      res.json(executions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch executions" });
    }
  });

  // AI Code Completion
  app.post("/api/ai/complete", async (req, res) => {
    try {
      const { code, language, cursorPosition } = req.body;
      const completions = await aiService.getCodeCompletions(code, language, cursorPosition);
      res.json(completions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get code completions" });
    }
  });

  // AI Code Fix
  app.post("/api/ai/fix", async (req, res) => {
    try {
      const { code, language, errorMessage } = req.body;
      const fix = await aiService.fixCode(code, language, errorMessage);
      res.json(fix);
    } catch (error) {
      res.status(500).json({ message: "Failed to fix code" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function getFileExtension(language: string): string {
  switch (language) {
    case "javascript":
      return "js";
    case "python":
      return "py";
    case "html":
      return "html";
    case "css":
      return "css";
    case "typescript":
      return "ts";
    default:
      return "txt";
  }
}

function getDefaultContent(language: string): string {
  switch (language) {
    case "javascript":
      return `console.log("Hello, World!");

// Your JavaScript code here
function greet(name) {
  return \`Hello, \${name}!\`;
}

greet("CodeCraft");`;
    case "python":
      return `print("Hello, World!")

# Your Python code here
def greet(name):
    return f"Hello, {name}!"

greet("CodeCraft")`;
    case "html":
      return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Web App</title>
</head>
<body>
    <h1>Hello, World!</h1>
    <p>Welcome to your web application!</p>
</body>
</html>`;
    case "css":
      return `/* Your CSS styles here */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
    background-color: #f5f5f5;
}

h1 {
    color: #333;
    text-align: center;
}`;
    default:
      return "// Start coding here...";
  }
}
