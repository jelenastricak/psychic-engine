import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Play, Code, Search, User, ChevronDown } from "lucide-react";
import type { Project } from "@shared/schema";

interface HeaderProps {
  currentProject?: Project;
  onRunCode: () => void;
  onCreateProject: (name: string, language: string) => void;
}

export default function Header({ currentProject, onRunCode, onCreateProject }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <header className="bg-dark-surface border-b border-dark-border flex items-center justify-between px-4 py-2 flex-shrink-0">
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <Code className="text-vscode-blue text-xl" />
          <h1 className="text-lg font-semibold">CodeCraft IDE</h1>
        </div>
        <nav className="hidden md:flex space-x-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="text-dark-text-secondary hover:text-dark-text px-3 py-1">
                File <ChevronDown className="ml-1 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-dark-surface border-dark-border">
              <DropdownMenuItem onClick={() => onCreateProject("New Project", "javascript")}>
                New Project
              </DropdownMenuItem>
              <DropdownMenuItem>Open Project</DropdownMenuItem>
              <DropdownMenuItem>Save All</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button variant="ghost" className="text-dark-text-secondary hover:text-dark-text px-3 py-1">
            Edit
          </Button>
          <Button variant="ghost" className="text-dark-text-secondary hover:text-dark-text px-3 py-1">
            View
          </Button>
          <Button variant="ghost" className="text-dark-text-secondary hover:text-dark-text px-3 py-1">
            Run
          </Button>
          <Button variant="ghost" className="text-dark-text-secondary hover:text-dark-text px-3 py-1">
            Help
          </Button>
        </nav>
      </div>
      
      <div className="flex items-center space-x-3">
        <div className="flex items-center space-x-2 bg-dark-bg rounded-lg px-3 py-1.5">
          <Search className="text-dark-text-secondary h-4 w-4" />
          <Input
            type="text"
            placeholder="Search files..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-transparent text-sm outline-none w-48 placeholder-dark-text-secondary border-none"
          />
        </div>
        <Button 
          onClick={onRunCode}
          className="bg-vscode-blue hover:bg-blue-600 text-white px-4 py-1.5 text-sm font-medium"
          disabled={!currentProject}
        >
          <Play className="mr-1 h-4 w-4" />
          Run Code
        </Button>
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-vscode-blue to-success-green flex items-center justify-center">
          <User className="text-white h-4 w-4" />
        </div>
      </div>
    </header>
  );
}
