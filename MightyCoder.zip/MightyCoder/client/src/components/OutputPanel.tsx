import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Eye, Terminal, Bug, Play, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import type { Project, File } from "@shared/schema";

interface OutputPanelProps {
  activeTab: "preview" | "console" | "debug";
  onTabChange: (tab: "preview" | "console" | "debug") => void;
  project?: Project;
  selectedFile: File | null;
}

export default function OutputPanel({ 
  activeTab, 
  onTabChange, 
  project, 
  selectedFile 
}: OutputPanelProps) {
  const [output, setOutput] = useState("");
  const [error, setError] = useState("");
  const [isExecuting, setIsExecuting] = useState(false);
  const [previewContent, setPreviewContent] = useState("");

  useEffect(() => {
    if (selectedFile?.language === "html") {
      setPreviewContent(selectedFile.content || "");
    }
  }, [selectedFile]);

  const executeCode = async () => {
    if (!project || !selectedFile) return;
    
    setIsExecuting(true);
    setError("");
    
    try {
      const response = await apiRequest(
        "POST",
        `/api/projects/${project.id}/execute`,
        {
          code: selectedFile.content,
          language: selectedFile.language,
        }
      );
      
      const result = await response.json();
      setOutput(result.output || "");
      setError(result.error || "");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Execution failed");
    } finally {
      setIsExecuting(false);
    }
  };

  const renderPreview = () => {
    if (selectedFile?.language === "html") {
      return (
        <div className="flex-1 bg-white m-2 rounded shadow-inner overflow-hidden">
          <iframe
            srcDoc={previewContent}
            className="w-full h-full border-none"
            title="HTML Preview"
          />
        </div>
      );
    }
    
    return (
      <div className="flex-1 bg-white m-2 rounded shadow-inner flex items-center justify-center">
        <div className="text-center p-8 text-gray-500">
          <Eye className="h-12 w-12 mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">No preview available</h3>
          <p>Preview is only available for HTML files</p>
        </div>
      </div>
    );
  };

  const renderConsole = () => {
    return (
      <div className="flex-1 flex flex-col">
        <div className="border-b border-dark-border p-2">
          <Button
            onClick={executeCode}
            disabled={isExecuting || !selectedFile}
            className="bg-success-green hover:bg-green-600 text-white"
            size="sm"
          >
            {isExecuting ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Play className="h-4 w-4 mr-2" />
            )}
            Run Code
          </Button>
        </div>
        
        <ScrollArea className="flex-1 p-2">
          <div className="font-mono text-sm">
            {output && (
              <div className="mb-4">
                <div className="text-success-green text-xs mb-1">OUTPUT:</div>
                <pre className="text-dark-text whitespace-pre-wrap">{output}</pre>
              </div>
            )}
            
            {error && (
              <div className="mb-4">
                <div className="text-error-red text-xs mb-1">ERROR:</div>
                <pre className="text-error-red whitespace-pre-wrap">{error}</pre>
              </div>
            )}
            
            {!output && !error && !isExecuting && (
              <div className="text-dark-text-secondary text-center py-8">
                <Terminal className="h-8 w-8 mx-auto mb-2" />
                <p>Click "Run Code" to execute your code</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>
    );
  };

  const renderDebug = () => {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center p-8 text-dark-text-secondary">
          <Bug className="h-12 w-12 mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">Debug Panel</h3>
          <p>Debugging features coming soon</p>
        </div>
      </div>
    );
  };

  return (
    <div className="w-1/3 border-l border-dark-border bg-dark-surface flex flex-col">
      <Tabs value={activeTab} onValueChange={(value) => onTabChange(value as any)}>
        <TabsList className="w-full bg-dark-surface border-b border-dark-border rounded-none">
          <TabsTrigger value="preview" className="flex-1 data-[state=active]:bg-dark-bg">
            <Eye className="h-4 w-4 mr-2" />
            Preview
          </TabsTrigger>
          <TabsTrigger value="console" className="flex-1 data-[state=active]:bg-dark-bg">
            <Terminal className="h-4 w-4 mr-2" />
            Console
          </TabsTrigger>
          <TabsTrigger value="debug" className="flex-1 data-[state=active]:bg-dark-bg">
            <Bug className="h-4 w-4 mr-2" />
            Debug
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="preview" className="flex-1 m-0">
          {renderPreview()}
        </TabsContent>
        
        <TabsContent value="console" className="flex-1 m-0">
          {renderConsole()}
        </TabsContent>
        
        <TabsContent value="debug" className="flex-1 m-0">
          {renderDebug()}
        </TabsContent>
      </Tabs>
    </div>
  );
}
