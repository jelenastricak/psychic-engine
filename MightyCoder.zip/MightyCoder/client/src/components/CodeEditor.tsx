import { useEffect, useRef, useState } from "react";
import { Editor } from "@monaco-editor/react";
import { useFiles } from "@/hooks/useFiles";
import { useAI } from "@/hooks/useAI";
import { Card } from "@/components/ui/card";
import { Loader2, Code } from "lucide-react";
import type { File } from "@shared/schema";

interface CodeEditorProps {
  file: File | null;
  onCodeChange: (code: string) => void;
}

export default function CodeEditor({ file, onCodeChange }: CodeEditorProps) {
  const [code, setCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const editorRef = useRef<any>(null);
  const { updateFile } = useFiles();
  const { getCodeCompletions } = useAI();

  useEffect(() => {
    if (file) {
      setCode(file.content || "");
    }
  }, [file]);

  const handleEditorChange = (value: string | undefined) => {
    if (value !== undefined) {
      setCode(value);
      onCodeChange(value);
      
      // Auto-save after 2 seconds of inactivity
      const timer = setTimeout(() => {
        if (file) {
          updateFile(file.id, { content: value });
        }
      }, 2000);
      
      return () => clearTimeout(timer);
    }
  };

  const handleEditorDidMount = (editor: any, monaco: any) => {
    editorRef.current = editor;
    
    // Configure Monaco theme
    monaco.editor.defineTheme('dark-theme', {
      base: 'vs-dark',
      inherit: true,
      rules: [],
      colors: {
        'editor.background': '#1E1E1E',
        'editor.foreground': '#CCCCCC',
        'editor.lineHighlightBackground': '#2D2D2D',
        'editor.selectionBackground': '#264F78',
        'editor.inactiveSelectionBackground': '#3A3D41',
      }
    });
    
    monaco.editor.setTheme('dark-theme');
    
    // Add custom keybindings
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.Space, () => {
      editor.trigger('', 'editor.action.triggerSuggest', {});
    });
  };

  const getLanguageForMonaco = (language: string) => {
    switch (language) {
      case "javascript":
        return "javascript";
      case "python":
        return "python";
      case "html":
        return "html";
      case "css":
        return "css";
      case "typescript":
        return "typescript";
      default:
        return "plaintext";
    }
  };

  if (!file) {
    return (
      <div className="flex-1 flex items-center justify-center bg-dark-bg">
        <Card className="p-8 bg-dark-surface border-dark-border">
          <div className="text-center">
            <Code className="h-12 w-12 text-dark-text-secondary mx-auto mb-4" />
            <h3 className="text-lg font-medium text-dark-text mb-2">No file selected</h3>
            <p className="text-dark-text-secondary">
              Select a file from the explorer to start coding
            </p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex-1 relative">
      {isLoading && (
        <div className="absolute inset-0 bg-dark-bg bg-opacity-50 flex items-center justify-center z-10">
          <div className="flex items-center space-x-2 text-dark-text">
            <Loader2 className="h-5 w-5 animate-spin" />
            <span>Loading editor...</span>
          </div>
        </div>
      )}
      
      <Editor
        height="100%"
        language={getLanguageForMonaco(file.language)}
        value={code}
        theme="dark-theme"
        onChange={handleEditorChange}
        onMount={handleEditorDidMount}
        options={{
          minimap: { enabled: false },
          fontSize: 14,
          lineNumbers: "on",
          renderWhitespace: "selection",
          automaticLayout: true,
          wordWrap: "on",
          scrollBeyondLastLine: false,
          folding: true,
          lineNumbersMinChars: 3,
          glyphMargin: true,
          contextmenu: true,
          quickSuggestions: true,
          suggestOnTriggerCharacters: true,
          acceptSuggestionOnEnter: "on",
          tabCompletion: "on",
          parameterHints: { enabled: true },
          autoClosingBrackets: "always",
          autoClosingQuotes: "always",
          formatOnType: true,
          formatOnPaste: true,
        }}
      />
    </div>
  );
}
