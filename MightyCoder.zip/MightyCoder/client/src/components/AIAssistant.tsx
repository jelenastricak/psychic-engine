import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAI } from "@/hooks/useAI";
import { Bot, Lightbulb, Loader2, RefreshCw } from "lucide-react";
import type { File } from "@shared/schema";

interface AIAssistantProps {
  selectedFile: File | null;
}

export default function AIAssistant({ selectedFile }: AIAssistantProps) {
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { analyzeSuggestions } = useAI();

  useEffect(() => {
    if (selectedFile && selectedFile.content) {
      analyzeSuggestions(selectedFile.id, selectedFile.content, selectedFile.language)
        .then(setSuggestions)
        .catch(() => setSuggestions([]));
    }
  }, [selectedFile, analyzeSuggestions]);

  const handleAnalyze = async () => {
    if (!selectedFile) return;
    
    setIsAnalyzing(true);
    try {
      const newSuggestions = await analyzeSuggestions(
        selectedFile.id,
        selectedFile.content || "",
        selectedFile.language
      );
      setSuggestions(newSuggestions);
    } catch (error) {
      console.error("Analysis failed:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getSuggestionIcon = (type: string) => {
    switch (type) {
      case "error":
        return "text-error-red";
      case "warning":
        return "text-warning-amber";
      case "optimization":
        return "text-vscode-blue";
      case "style":
        return "text-purple-400";
      default:
        return "text-dark-text-secondary";
    }
  };

  return (
    <div className="border-t border-dark-border p-3">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center space-x-2">
          <Bot className="text-vscode-blue h-4 w-4" />
          <span className="text-sm font-medium">AI Assistant</span>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleAnalyze}
          disabled={!selectedFile || isAnalyzing}
          className="p-1"
        >
          {isAnalyzing ? (
            <Loader2 className="h-3 w-3 animate-spin" />
          ) : (
            <RefreshCw className="h-3 w-3" />
          )}
        </Button>
      </div>
      
      <ScrollArea className="h-32">
        {suggestions.length > 0 ? (
          <div className="space-y-2">
            {suggestions.map((suggestion, index) => (
              <Card key={index} className="bg-dark-bg border-dark-border p-2">
                <div className="flex items-start space-x-2">
                  <Lightbulb className={`h-3 w-3 mt-0.5 ${getSuggestionIcon(suggestion.type)}`} />
                  <div className="flex-1">
                    <div className="text-xs text-dark-text-secondary mb-1">
                      {suggestion.type.toUpperCase()}
                      {suggestion.lineNumber && ` (Line ${suggestion.lineNumber})`}
                    </div>
                    <p className="text-xs text-dark-text leading-relaxed">
                      {suggestion.message}
                    </p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-4">
            {selectedFile ? (
              <div className="text-xs text-dark-text-secondary">
                <Lightbulb className="h-4 w-4 mx-auto mb-2" />
                <p>Click refresh to analyze your code</p>
              </div>
            ) : (
              <div className="text-xs text-dark-text-secondary">
                <Bot className="h-4 w-4 mx-auto mb-2" />
                <p>Select a file to get AI suggestions</p>
              </div>
            )}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}
