import OpenAI from "openai";

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export class AIService {
  async analyzeCode(code: string, language: string): Promise<{
    type: string;
    message: string;
    lineNumber: number | null;
  }[]> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: `You are a code analysis expert. Analyze the provided ${language} code and provide suggestions for improvements, optimizations, and error fixes. Return your analysis as a JSON array of objects with the following structure: [{ "type": "error|warning|optimization|style", "message": "description of the issue and suggested fix", "lineNumber": number or null }]`
          },
          {
            role: "user",
            content: `Please analyze this ${language} code:\n\n${code}`
          }
        ],
        response_format: { type: "json_object" }
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      return result.suggestions || [];
    } catch (error) {
      console.error("AI analysis failed:", error);
      return [];
    }
  }

  async getCodeCompletions(code: string, language: string, cursorPosition: number): Promise<{
    suggestions: string[];
    insertText: string;
  }[]> {
    try {
      const beforeCursor = code.substring(0, cursorPosition);
      const afterCursor = code.substring(cursorPosition);

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: `You are a code completion expert. Given ${language} code with a cursor position, provide intelligent code completions. Return your suggestions as a JSON object with the following structure: { "completions": [{ "suggestions": ["completion1", "completion2"], "insertText": "text to insert" }] }`
          },
          {
            role: "user",
            content: `Code before cursor:\n${beforeCursor}\n\nCode after cursor:\n${afterCursor}\n\nProvide completions for the cursor position.`
          }
        ],
        response_format: { type: "json_object" }
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      return result.completions || [];
    } catch (error) {
      console.error("Code completion failed:", error);
      return [];
    }
  }

  async fixCode(code: string, language: string, errorMessage: string): Promise<{
    fixedCode: string;
    explanation: string;
  }> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: `You are a code fixing expert. Given ${language} code with an error, provide a fixed version and explanation. Return your response as a JSON object with the following structure: { "fixedCode": "corrected code", "explanation": "explanation of what was fixed" }`
          },
          {
            role: "user",
            content: `Fix this ${language} code:\n\n${code}\n\nError: ${errorMessage}`
          }
        ],
        response_format: { type: "json_object" }
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      return {
        fixedCode: result.fixedCode || code,
        explanation: result.explanation || "No fix suggestions available"
      };
    } catch (error) {
      console.error("Code fix failed:", error);
      return {
        fixedCode: code,
        explanation: "Failed to generate code fix"
      };
    }
  }
}

export const aiService = new AIService();
