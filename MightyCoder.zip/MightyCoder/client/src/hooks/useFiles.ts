import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { File, InsertFile } from "@shared/schema";

export function useFiles(projectId?: number) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: files, isLoading, error } = useQuery<File[]>({
    queryKey: ["/api/projects", projectId, "files"],
    enabled: !!projectId,
  });

  const createFileMutation = useMutation({
    mutationFn: async (file: InsertFile) => {
      const response = await apiRequest("POST", `/api/projects/${file.projectId}/files`, file);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "files"] });
      toast({
        title: "Success",
        description: "File created successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create file",
        variant: "destructive",
      });
    },
  });

  const updateFileMutation = useMutation({
    mutationFn: async ({ id, file }: { id: number; file: Partial<InsertFile> }) => {
      const response = await apiRequest("PUT", `/api/files/${id}`, file);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "files"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update file",
        variant: "destructive",
      });
    },
  });

  const deleteFileMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/files/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "files"] });
      toast({
        title: "Success",
        description: "File deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete file",
        variant: "destructive",
      });
    },
  });

  return {
    files,
    isLoading,
    error,
    createFile: createFileMutation.mutateAsync,
    updateFile: updateFileMutation.mutateAsync,
    deleteFile: deleteFileMutation.mutateAsync,
    isCreating: createFileMutation.isPending,
    isUpdating: updateFileMutation.isPending,
    isDeleting: deleteFileMutation.isPending,
  };
}
