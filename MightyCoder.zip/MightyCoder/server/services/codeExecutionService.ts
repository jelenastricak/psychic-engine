export class CodeExecutionService {
  async executeCode(code: string, language: string): Promise<{
    output: string;
    error: string | null;
    executionTime: number;
  }> {
    const startTime = Date.now();
    
    try {
      let result;
      
      switch (language) {
        case "javascript":
          result = await this.executeJavaScript(code);
          break;
        case "python":
          result = await this.executePython(code);
          break;
        case "html":
          result = await this.executeHTML(code);
          break;
        default:
          throw new Error(`Unsupported language: ${language}`);
      }
      
      const executionTime = Date.now() - startTime;
      
      return {
        output: result.output,
        error: result.error,
        executionTime
      };
    } catch (error) {
      const executionTime = Date.now() - startTime;
      return {
        output: "",
        error: error instanceof Error ? error.message : "Unknown error",
        executionTime
      };
    }
  }

  private async executeJavaScript(code: string): Promise<{ output: string; error: string | null }> {
    try {
      // Create a safe execution environment using Node.js VM
      const { VM } = require("vm2");
      const vm = new VM({
        timeout: 5000,
        sandbox: {
          console: {
            log: (...args: any[]) => {
              output.push(args.map(arg => typeof arg === 'object' ? JSON.stringify(arg) : String(arg)).join(' '));
            }
          }
        }
      });

      const output: string[] = [];
      const result = vm.run(code);
      
      if (result !== undefined) {
        output.push(String(result));
      }
      
      return {
        output: output.join('\n'),
        error: null
      };
    } catch (error) {
      return {
        output: "",
        error: error instanceof Error ? error.message : "JavaScript execution failed"
      };
    }
  }

  private async executePython(code: string): Promise<{ output: string; error: string | null }> {
    try {
      // For Python execution, we would need to use a Python interpreter
      // This is a simplified implementation - in production, you'd use a proper Python sandbox
      const { spawn } = require("child_process");
      
      return new Promise((resolve) => {
        const python = spawn("python3", ["-c", code]);
        let output = "";
        let error = "";
        
        python.stdout.on("data", (data: Buffer) => {
          output += data.toString();
        });
        
        python.stderr.on("data", (data: Buffer) => {
          error += data.toString();
        });
        
        python.on("close", (code: number) => {
          resolve({
            output: output.trim(),
            error: error.trim() || null
          });
        });
        
        // Timeout after 5 seconds
        setTimeout(() => {
          python.kill();
          resolve({
            output: "",
            error: "Execution timeout"
          });
        }, 5000);
      });
    } catch (error) {
      return {
        output: "",
        error: error instanceof Error ? error.message : "Python execution failed"
      };
    }
  }

  private async executeHTML(code: string): Promise<{ output: string; error: string | null }> {
    try {
      // For HTML, we just return the code as it would be rendered
      return {
        output: code,
        error: null
      };
    } catch (error) {
      return {
        output: "",
        error: error instanceof Error ? error.message : "HTML processing failed"
      };
    }
  }
}

export const codeExecutionService = new CodeExecutionService();
